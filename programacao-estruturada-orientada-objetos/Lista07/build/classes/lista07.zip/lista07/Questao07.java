package lista07;

/*
Escreva um programa contendo uma função que imprime na tela o conteúdo de
qualquer vetor de char passado como parâmetro.
 */
public class Questao07 {

    public static void main(String[] args) {

        char[] vetorP = {'M', 'i', 's', 'l', 'a'};

        System.out.println(vetor(vetorP));
    }

    public static char[] vetor(char[] vetorP) {

        char[] v = vetorP;

        return v;
    }
}