package doador;

public class Doador {

    //Atributos
    private String nome, tSanguineo;
    private int idade;
    private float peso;

    //Métodos especiais
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String gettSanguineo() {
        return tSanguineo;
    }

    public void settSanguineo(String tSanguineo) {
        this.tSanguineo = tSanguineo;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    //Métodos abstratos
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Nome: ");
        sb.append(nome);
        sb.append(", Tipo sanguíneo: ");
        sb.append(tSanguineo);

        return sb.toString();

    }

}
